package com.redsocial.servicio;

import java.util.List;

import com.redsocial.entidad.Categoria;

public interface CategoriaServicio {
public abstract List<Categoria> listaCategoria();
}

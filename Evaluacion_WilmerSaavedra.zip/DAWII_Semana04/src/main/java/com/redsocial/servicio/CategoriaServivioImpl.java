package com.redsocial.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.redsocial.entidad.Categoria;
import com.redsocial.repositorio.CategoriaRepositorio;
@Service
public class CategoriaServivioImpl implements CategoriaServicio{

	@Autowired
	private CategoriaRepositorio service;
	
	@Override
	public List<Categoria> listaCategoria() {
		return service.findAll();
	}
}

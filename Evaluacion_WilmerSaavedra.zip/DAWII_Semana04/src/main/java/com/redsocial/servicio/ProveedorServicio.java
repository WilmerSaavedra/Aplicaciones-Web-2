package com.redsocial.servicio;

import com.redsocial.entidad.Proveedor;

public interface ProveedorServicio {
public  Proveedor insertaProveedor(Proveedor obj);
}

package com.redsocial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DawiiSemana04Application {

	public static void main(String[] args) {
		SpringApplication.run(DawiiSemana04Application.class, args);
	}

}

package com.redsocial.controlador;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.redsocial.entidad.Categoria;
import com.redsocial.entidad.Proveedor;
import com.redsocial.servicio.CategoriaServicio;
import com.redsocial.servicio.ProveedorServicio;

@Controller
public class ProveedorController {

	@Autowired
	private ProveedorServicio servicioprov;
	
	@Autowired
	private CategoriaServicio serviciocat;
	
	@RequestMapping("/verProveedor")
	public String ver() {
		return "registraProveedor";
	}
	

	@RequestMapping("/cargaCategoria")
	@ResponseBody
	public List<Categoria> lista() {
		return serviciocat.listaCategoria();
	}
	

	@RequestMapping(value="/registraProveedor", method = RequestMethod.POST)
	public String regDeporte(Proveedor modalidad, HttpSession session) {
		
		Proveedor aux = servicioprov.insertaProveedor(modalidad);
		if(aux == null) {
			session.setAttribute("MENSAJE", "Registro erróneo");
		}else {
			session.setAttribute("MENSAJE", "Registro exitos");
		}
		
		return "registraProveedor";
	}

	
}
